import { useState } from 'react';
import reactLogo from './assets/react.svg';
import viteLogo from '/vite.svg';
import './App.css';
import OnorNot from './Conditional_Rendering_Challenge/prelimexam';

function App() {
  const items = ['My Strawhat', 'Gum gum Fruit', 'The Red Vest'];

  const renderList = items.map((item, index) => <div key={index}>{item}</div>);

  return (
    <>
      <h1>Things to Bring</h1>
      <div>
        <OnorNot isOnHand={true} />
      </div>
      <div className="items">{renderList[0]}</div>
      <div className="items">{renderList[1]}</div>
      <div className="items">{renderList[2]}</div>
    </>
  );
}

export default App;
