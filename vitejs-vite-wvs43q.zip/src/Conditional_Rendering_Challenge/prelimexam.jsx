import React from 'react';

function onHand() {
  return <mark green>highlight</mark>;
}

function OnorNot(props) {
  const isOnHand = props.isOnHand;
  if (isOnHand) {
    return <onHand />;
  }
  return <mark pink>highlight</mark>;
}

export default OnorNot;
